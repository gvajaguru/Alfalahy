// Sample JSON data for the schedule
const scheduleData = {
    "weeks": [
        {
            "weekNumber": 1,
            "dateRange": "Jun 1-7",
            "classes": [
                {
                    "className": "5A",
                    "schedule": [
                        {
                            "time": "9:00-10:00",
                            "monday": {
                                "subject": "Mathematics",
                                "tutor": "Mr. Smith"
                            },
                            "tuesday": {},
                            "wednesday": {
                                "subject": "Science",
                                "tutor": "Ms. Johnson"
                            },
                            "thursday": {
                                "subject": "History",
                                "tutor": "Mr. Brown"
                            },
                            "friday": {
                                "subject": "Art",
                                "tutor": "Ms. Davis"
                            }
                        },
                        {
                            "time": "10:00-11:00",
                            "monday": {
                                "subject": "Geography",
                                "tutor": "Mr. Clark"
                            },
                            "tuesday": {
                                "subject": "Music",
                                "tutor": "Mr. Taylor"
                            },
                            "wednesday": {
                                "subject": "Physical Ed",
                                "tutor": "Coach Thomas"
                            },
                            "thursday": {
                                "subject": "Economics",
                                "tutor": "Dr. Martin"
                            },
                            "friday": {
                                "subject": "Drama",
                                "tutor": "Ms. Garcia"
                            }
                        },
                        {
                            "time": "11:00-12:00",
                            "monday": {
                                "subject": "Math Olympiad",
                                "tutor": "Mr. Smith",
                                "rowspan": 2
                            },
                            "tuesday": {
                                "subject": "Literature",
                                "tutor": "Ms. Robinson"
                            },
                            "wednesday": {
                                "subject": "Lab Session",
                                "tutor": "Dr. Hall",
                                "rowspan": 2
                            },
                            "thursday": {
                                "subject": "Psychology",
                                "tutor": "Dr. Lewis"
                            },
                            "friday": {
                                "subject": "Sociology",
                                "tutor": "Dr. Lee"
                            }
                        },
                        {
                            "time": "12:00-1:00",
                            "tuesday": {
                                "subject": "Political Science",
                                "tutor": "Prof. Walker"
                            },
                            "thursday": {
                                "subject": "Statistics",
                                "tutor": "Prof. Allen"
                            },
                            "friday": {
                                "subject": "Calculus",
                                "tutor": "Prof. Young"
                            }
                        },
                        {
                            "time": "2:00-3:00",
                            "monday": {
                                "subject": "Foreign Language",
                                "tutor": "Ms. Hernandez"
                            },
                            "tuesday": {
                                "subject": "Research Project",
                                "tutor": "Dr. Clark",
                                "rowspan": 3
                            },
                            "wednesday": {
                                "subject": "Philosophy",
                                "tutor": "Dr. Rodriguez"
                            },
                            "thursday": {
                                "subject": "Computer Science",
                                "tutor": "Mr. Allen"
                            },
                            "friday": {
                                "subject": "Creative Writing",
                                "tutor": "Mr. King"
                            }
                        },
                        {
                            "time": "3:00-4:00",
                            "monday": {
                                "subject": "Physics",
                                "tutor": "Dr. White"
                            },
                            "wednesday": {
                                "subject": "Chemistry",
                                "tutor": "Ms. Green"
                            },
                            "thursday": {
                                "subject": "Biology",
                                "tutor": "Dr. Miller"
                            },
                            "friday": {
                                "subject": "Debate",
                                "tutor": "Mr. Wright"
                            }
                        },
                        {
                            "time": "4:00-5:00",
                            "monday": {
                                "subject": "Field Study",
                                "tutor": "Mr. Brown"
                            },
                            "wednesday": {},
                            "thursday": {},
                            "friday": {}
                        }
                    ]
                },
                {
                    "className": "6B",
                    "schedule": [
                        {
                            "time": "9:00-10:00",
                            "monday": {
                                "subject": "Mathematics",
                                "tutor": "Mr. Lee"
                            },
                            "tuesday": {
                                "subject": "Science",
                                "tutor": "Ms. Johnson"
                            },
                            "wednesday": {
                                "subject": "English",
                                "tutor": "Mrs. King"
                            },
                            "thursday": {
                                "subject": "Art",
                                "tutor": "Ms. Davis"
                            },
                            "friday": {
                                "subject": "Computer Science",
                                "tutor": "Mr. Allen"
                            }
                        },
                        {
                            "time": "10:00-11:00",
                            "monday": {
                                "subject": "Science Fair Prep",
                                "tutor": "Ms. Johnson",
                                "rowspan": 4
                            },
                            "tuesday": {
                                "subject": "History",
                                "tutor": "Mr. Wilson"
                            },
                            "wednesday": {
                                "subject": "Physical Ed",
                                "tutor": "Coach Thomas"
                            },
                            "thursday": {
                                "subject": "Art Workshop",
                                "tutor": "Ms. Davis",
                                "rowspan": 4
                            },
                            "friday": {
                                "subject": "Literature",
                                "tutor": "Ms. Robinson"
                            }
                        },
                        {
                            "time": "11:00-12:00",
                            "tuesday": {
                                "subject": "Music",
                                "tutor": "Mr. Taylor"
                            },
                            "wednesday": {
                                "subject": "Economics",
                                "tutor": "Dr. Martin"
                            },
                            "friday": {
                                "subject": "Drama",
                                "tutor": "Ms. Garcia"
                            }
                        },
                        {
                            "time": "12:00-1:00",
                            "tuesday": {
                                "subject": "Geography",
                                "tutor": "Mr. Clark"
                            },
                            "wednesday": {
                                "subject": "Psychology",
                                "tutor": "Dr. Lewis"
                            },
                            "friday": {
                                "subject": "Sociology",
                                "tutor": "Dr. Lee"
                            }
                        },
                        {
                            "time": "2:00-3:00",

                            "tuesday": {
                                "subject": "Statistics",
                                "tutor": "Prof. Allen"
                            },
                            "wednesday": {
                                "subject": "Calculus",
                                "tutor": "Prof. Young"
                            },
                            "friday": {
                                "subject": "Creative Writing",
                                "tutor": "Mr. King"
                            }
                        },
                        {
                            "time": "3:00-4:00",
                            "monday": {
                                "subject": "Foreign Language",
                                "tutor": "Ms. Hernandez"
                            },
                            "tuesday": {
                                "subject": "Physics",
                                "tutor": "Dr. White"
                            },
                            "wednesday": {
                                "subject": "Chemistry",
                                "tutor": "Ms. Green"
                            },
                            "thursday": {
                                "subject": "Biology",
                                "tutor": "Dr. Miller"
                            },
                            "friday": {
                                "subject": "Debate",
                                "tutor": "Mr. Wright"
                            }
                        },
                        {
                            "time": "4:00-5:00",
                            "monday": {
                                "subject": "Field Study",
                                "tutor": "Mr. Brown"
                            },
                            "tuesday": {},
                            "wednesday": {},
                            "thursday": {},
                            "friday": {}
                        }
                    ]
                }
            ]
        },
        {
            "weekNumber": 2,
            "dateRange": "Jun 8-14",
            "classes": [
                {
                    "className": "5A",
                    "schedule": [
                        {
                            "time": "9:00-10:00",
                            "monday": {
                                "subject": "Biology",
                                "tutor": "Dr. Miller"
                            },
                            "tuesday": {
                                "subject": "Chemistry",
                                "tutor": "Ms. Green"
                            },
                            "wednesday": {
                                "subject": "Physics",
                                "tutor": "Dr. White"
                            },
                            "thursday": {
                                "subject": "Computer Science",
                                "tutor": "Mr. Allen"
                            },
                            "friday": {
                                "subject": "Mathematics",
                                "tutor": "Mr. Smith"
                            }
                        },
                        {
                            "time": "10:00-11:00",
                            "monday": {
                                "subject": "Literature",
                                "tutor": "Ms. Robinson"
                            },
                            "tuesday": {
                                "subject": "Political Science",
                                "tutor": "Prof. Walker"
                            },
                            "wednesday": {
                                "subject": "Foreign Language",
                                "tutor": "Ms. Hernandez"
                            },
                            "thursday": {
                                "subject": "Statistics",
                                "tutor": "Prof. Allen"
                            },
                            "friday": {
                                "subject": "Calculus",
                                "tutor": "Prof. Young"
                            }
                        },
                        {
                            "time": "11:00-12:00",
                            "monday": {
                                "subject": "Lab Session",
                                "tutor": "Dr. Hall",
                                "rowspan": 2
                            },
                            "tuesday": {
                                "subject": "Psychology",
                                "tutor": "Dr. Lewis"
                            },
                            "wednesday": {
                                "subject": "Sociology",
                                "tutor": "Dr. Lee",
                                "rowspan": 2
                            },
                            "thursday": {
                                "subject": "Philosophy",
                                "tutor": "Dr. Rodriguez"
                            },
                            "friday": {
                                "subject": "Creative Writing",
                                "tutor": "Mr. King"
                            }
                        },
                        {
                            "time": "12:00-1:00",
                            "tuesday": {
                                "subject": "Economics",
                                "tutor": "Dr. Martin"
                            },
                            "thursday": {
                                "subject": "Art",
                                "tutor": "Ms. Davis"
                            },
                            "friday": {
                                "subject": "Drama",
                                "tutor": "Ms. Garcia"
                            }
                        },
                        {
                            "time": "2:00-3:00",
                            "monday": {
                                "subject": "History",
                                "tutor": "Mr. Brown"
                            },
                            "tuesday": {
                                "subject": "Geography",
                                "tutor": "Mr. Clark",
                                "rowspan": 3
                            },
                            "wednesday": {
                                "subject": "English",
                                "tutor": "Ms. Adams"
                            },
                            "thursday": {
                                "subject": "Science",
                                "tutor": "Ms. Johnson"
                            },
                            "friday": {
                                "subject": "Music",
                                "tutor": "Mr. Taylor"
                            }
                        },
                        {
                            "time": "3:00-4:00",
                            "monday": {
                                "subject": "Physical Ed",
                                "tutor": "Coach Thomas"
                            },
                            "wednesday": {
                                "subject": "Math Olympiad",
                                "tutor": "Mr. Smith"
                            },
                            "thursday": {
                                "subject": "Research Project",
                                "tutor": "Dr. Clark"
                            },
                            "friday": {
                                "subject": "Debate",
                                "tutor": "Mr. Wright"
                            }
                        },
                        {
                            "time": "4:00-5:00",
                            "monday": {
                                "subject": "Field Study",
                                "tutor": "Mr. Brown"
                            }
                        }
                    ]
                },
                {
                    "className": "6B",
                    "schedule": [
                        {
                            "time": "9:00-10:00",
                            "monday": {
                                "subject": "Computer Science",
                                "tutor": "Mr. Allen"
                            },
                            "tuesday": {
                                "subject": "Mathematics",
                                "tutor": "Mr. Lee"
                            },
                            "wednesday": {
                                "subject": "Science",
                                "tutor": "Ms. Johnson"
                            },
                            "thursday": {
                                "subject": "English",
                                "tutor": "Mrs. King"
                            },
                            "friday": {
                                "subject": "Art",
                                "tutor": "Ms. Davis"
                            }
                        },
                        {
                            "time": "10:00-11:00",
                            "monday": {
                                "subject": "Literature",
                                "tutor": "Ms. Robinson",
                                "rowspan": 4
                            },
                            "tuesday": {
                                "subject": "History",
                                "tutor": "Mr. Wilson"
                            },
                            "wednesday": {
                                "subject": "Physical Ed",
                                "tutor": "Coach Thomas"
                            },
                            "thursday": {
                                "subject": "Music",
                                "tutor": "Mr. Taylor",
                                "rowspan": 4
                            },
                            "friday": {
                                "subject": "Drama",
                                "tutor": "Ms. Garcia"
                            }
                        },
                        {
                            "time": "11:00-12:00",
                            "tuesday": {
                                "subject": "Economics",
                                "tutor": "Dr. Martin"
                            },
                            "wednesday": {
                                "subject": "Psychology",
                                "tutor": "Dr. Lewis"
                            },
                            "friday": {
                                "subject": "Sociology",
                                "tutor": "Dr. Lee"
                            }
                        },
                        {
                            "time": "12:00-1:00",
                            "tuesday": {
                                "subject": "Political Science",
                                "tutor": "Prof. Walker"
                            },
                            "wednesday": {
                                "subject": "Statistics",
                                "tutor": "Prof. Allen"
                            },
                            "friday": {
                                "subject": "Calculus",
                                "tutor": "Prof. Young"
                            }
                        },
                        {
                            "time": "2:00-3:00",

                            "tuesday": {
                                "subject": "Creative Writing",
                                "tutor": "Mr. King"
                            },
                            "wednesday": {
                                "subject": "Foreign Language",
                                "tutor": "Ms. Hernandez"
                            },
                            "friday": {
                                "subject": "Chemistry",
                                "tutor": "Ms. Green"
                            }
                        },
                        {
                            "time": "3:00-4:00",
                            "monday": {
                                "subject": "Biology",
                                "tutor": "Dr. Miller"
                            },
                            "tuesday": {
                                "subject": "Research Project",
                                "tutor": "Dr. Clark"
                            },
                            "wednesday": {
                                "subject": "Math Olympiad",
                                "tutor": "Mr. Smith"
                            },
                            "thursday": {
                                "subject": "Art Workshop",
                                "tutor": "Ms. Davis"
                            },
                            "friday": {
                                "subject": "Debate",
                                "tutor": "Mr. Wright"
                            }
                        },
                        {
                            "time": "4:00-5:00",
                            "monday": {
                                "subject": "Field Study",
                                "tutor": "Mr. Brown"
                            },
                            "tuesday": {},
                            "wednesday": {},
                            "thursday": {},
                            "friday": {}
                        }
                    ]
                }
            ]
        },
        {
            "weekNumber": 3,
            "dateRange": "Jun 15-21",
            "classes": [
                {
                    "className": "5A",
                    "schedule": [
                        {
                            "time": "9:00-10:00",
                            "monday": {
                                "subject": "Mathematics",
                                "tutor": "Mr. Smith"
                            },
                            "tuesday": {},
                            "wednesday": {
                                "subject": "Science",
                                "tutor": "Ms. Johnson"
                            },
                            "thursday": {
                                "subject": "History",
                                "tutor": "Mr. Brown"
                            },
                            "friday": {
                                "subject": "Art",
                                "tutor": "Ms. Davis"
                            }
                        },
                        {
                            "time": "10:00-11:00",
                            "monday": {
                                "subject": "Geography",
                                "tutor": "Mr. Clark"
                            },
                            "tuesday": {
                                "subject": "Music",
                                "tutor": "Mr. Taylor"
                            },
                            "wednesday": {
                                "subject": "Physical Ed",
                                "tutor": "Coach Thomas"
                            },
                            "thursday": {
                                "subject": "Economics",
                                "tutor": "Dr. Martin"
                            },
                            "friday": {
                                "subject": "Drama",
                                "tutor": "Ms. Garcia"
                            }
                        },
                        {
                            "time": "11:00-12:00",
                            "monday": {
                                "subject": "Math Olympiad",
                                "tutor": "Mr. Smith",
                                "rowspan": 2
                            },
                            "tuesday": {
                                "subject": "Literature",
                                "tutor": "Ms. Robinson"
                            },
                            "wednesday": {
                                "subject": "Lab Session",
                                "tutor": "Dr. Hall",
                                "rowspan": 2
                            },
                            "thursday": {
                                "subject": "Psychology",
                                "tutor": "Dr. Lewis"
                            },
                            "friday": {
                                "subject": "Sociology",
                                "tutor": "Dr. Lee"
                            }
                        },
                        {
                            "time": "12:00-1:00",
                            "tuesday": {
                                "subject": "Political Science",
                                "tutor": "Prof. Walker"
                            },
                            "thursday": {
                                "subject": "Statistics",
                                "tutor": "Prof. Allen"
                            },
                            "friday": {
                                "subject": "Calculus",
                                "tutor": "Prof. Young"
                            }
                        },
                        {
                            "time": "2:00-3:00",
                            "monday": {
                                "subject": "Foreign Language",
                                "tutor": "Ms. Hernandez"
                            },
                            "tuesday": {
                                "subject": "Research Project",
                                "tutor": "Dr. Clark",
                                "rowspan": 3
                            },
                            "wednesday": {
                                "subject": "Philosophy",
                                "tutor": "Dr. Rodriguez"
                            },
                            "thursday": {
                                "subject": "Computer Science",
                                "tutor": "Mr. Allen"
                            },
                            "friday": {
                                "subject": "Creative Writing",
                                "tutor": "Mr. King"
                            }
                        },
                        {
                            "time": "3:00-4:00",
                            "monday": {
                                "subject": "Physics",
                                "tutor": "Dr. White"
                            },
                            "wednesday": {
                                "subject": "Chemistry",
                                "tutor": "Ms. Green"
                            },
                            "thursday": {
                                "subject": "Biology",
                                "tutor": "Dr. Miller"
                            },
                            "friday": {
                                "subject": "Debate",
                                "tutor": "Mr. Wright"
                            }
                        },
                        {
                            "time": "4:00-5:00",
                            "monday": {
                                "subject": "Field Study",
                                "tutor": "Mr. Brown"
                            },
                            "wednesday": {},
                            "thursday": {},
                            "friday": {}
                        }
                    ]
                },
                {
                    "className": "6B",
                    "schedule": [
                        {
                            "time": "9:00-10:00",
                            "monday": {
                                "subject": "Mathematics",
                                "tutor": "Mr. Lee"
                            },
                            "tuesday": {
                                "subject": "Science",
                                "tutor": "Ms. Johnson"
                            },
                            "wednesday": {
                                "subject": "English",
                                "tutor": "Mrs. King"
                            },
                            "thursday": {
                                "subject": "Art",
                                "tutor": "Ms. Davis"
                            },
                            "friday": {
                                "subject": "Computer Science",
                                "tutor": "Mr. Allen"
                            }
                        },
                        {
                            "time": "10:00-11:00",
                            "monday": {
                                "subject": "Science Fair Prep",
                                "tutor": "Ms. Johnson",
                                "rowspan": 4
                            },
                            "tuesday": {
                                "subject": "History",
                                "tutor": "Mr. Wilson"
                            },
                            "wednesday": {
                                "subject": "Physical Ed",
                                "tutor": "Coach Thomas"
                            },
                            "thursday": {
                                "subject": "Art Workshop",
                                "tutor": "Ms. Davis",
                                "rowspan": 4
                            },
                            "friday": {
                                "subject": "Literature",
                                "tutor": "Ms. Robinson"
                            }
                        },
                        {
                            "time": "11:00-12:00",
                            "tuesday": {
                                "subject": "Music",
                                "tutor": "Mr. Taylor"
                            },
                            "wednesday": {
                                "subject": "Economics",
                                "tutor": "Dr. Martin"
                            },
                            "friday": {
                                "subject": "Drama",
                                "tutor": "Ms. Garcia"
                            }
                        },
                        {
                            "time": "12:00-1:00",
                            "tuesday": {
                                "subject": "Geography",
                                "tutor": "Mr. Clark"
                            },
                            "wednesday": {
                                "subject": "Psychology",
                                "tutor": "Dr. Lewis"
                            },
                            "friday": {
                                "subject": "Sociology",
                                "tutor": "Dr. Lee"
                            }
                        },
                        {
                            "time": "2:00-3:00",

                            "tuesday": {
                                "subject": "Statistics",
                                "tutor": "Prof. Allen"
                            },
                            "wednesday": {
                                "subject": "Calculus",
                                "tutor": "Prof. Young"
                            },
                            "friday": {
                                "subject": "Creative Writing",
                                "tutor": "Mr. King"
                            }
                        },
                        {
                            "time": "3:00-4:00",
                            "monday": {
                                "subject": "Foreign Language",
                                "tutor": "Ms. Hernandez"
                            },
                            "tuesday": {
                                "subject": "Physics",
                                "tutor": "Dr. White"
                            },
                            "wednesday": {
                                "subject": "Chemistry",
                                "tutor": "Ms. Green"
                            },
                            "thursday": {
                                "subject": "Biology",
                                "tutor": "Dr. Miller"
                            },
                            "friday": {
                                "subject": "Debate",
                                "tutor": "Mr. Wright"
                            }
                        },
                        {
                            "time": "4:00-5:00",
                            "monday": {
                                "subject": "Field Study",
                                "tutor": "Mr. Brown"
                            },
                            "tuesday": {},
                            "wednesday": {},
                            "thursday": {},
                            "friday": {}
                        }
                    ]
                }
            ]
        }

    ]
};

// Current week index
let currentWeekIndex = 0;
let isNavCollapsed = false;

// Function to render the schedule
function renderSchedule(weekIndex) {
    const scheduleBody = document.getElementById('schedule-body');
    scheduleBody.innerHTML = '';

    const weekData = scheduleData.weeks[weekIndex];
    document.getElementById('month-title').textContent = 'June 2025';
    document.getElementById('week-title').textContent = `Week ${weekData.weekNumber} (${weekData.dateRange})`;

    weekData.classes.forEach((classData, classIndex) => {
        // Add class rows
        classData.schedule.forEach((slot, slotIndex) => {
            const row = document.createElement('tr');

            // Add class cell for first row of each class
            if (slotIndex === 0) {
                const classCell = document.createElement('td');
                classCell.className = 'class-cell';
                classCell.textContent = classData.className;
                classCell.rowSpan = classData.schedule.length;
                row.appendChild(classCell);
            }

            // Add time cell
            const timeCell = document.createElement('td');
            timeCell.className = 'timing-cell';
            timeCell.textContent = slot.time;
            row.appendChild(timeCell);

            // Add day cells
            ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'].forEach(day => {
                const dayCell = document.createElement('td');
                if (slot.empty) {
                    dayCell.colSpan = 1;
                    const emptyDiv = document.createElement('div');
                    emptyDiv.className = 'empty-cell';
                    emptyDiv.textContent = 'No class';
                    dayCell.appendChild(emptyDiv);
                }
                else if (slot[day]) {
                    if (slot[day].subject == undefined) {
                        dayCell.colSpan = 1;
                        const emptyDiv = document.createElement('div');
                        emptyDiv.className = 'empty-cell';
                        emptyDiv.textContent = 'No class';
                        dayCell.appendChild(emptyDiv);
                        row.appendChild(dayCell);
                        return;
                    }
                    if (slot[day].rowspan) {
                        dayCell.rowSpan = slot[day].rowspan;
                    }
                    const subjectDiv = document.createElement('div');
                    subjectDiv.className = 'subject-card';
                    subjectDiv.textContent = slot[day].subject;
                    dayCell.appendChild(subjectDiv);

                    const tutorDiv = document.createElement('div');
                    tutorDiv.className = 'tutor-card';
                    tutorDiv.textContent = slot[day].tutor;
                    dayCell.appendChild(tutorDiv);
                }
                if (dayCell.textContent == "") {
                    return;
                }
                row.appendChild(dayCell);
            });

            scheduleBody.appendChild(row);
        });

        // Add gap between classes except after the last class
        if (classIndex < weekData.classes.length - 1) {
            const gapRow = document.createElement('tr');
            const gapCell = document.createElement('td');
            gapCell.colSpan = 7;
            gapCell.className = 'class-gap';
            gapRow.appendChild(gapCell);
            scheduleBody.appendChild(gapRow);
        }
    });
}

// Toggle navigation panel
function toggleNav() {
    const navContainer = document.querySelector('.nav-container');
    const navToggleIcon = document.querySelector('.nav-toggle i');
    const mobileNavToggle = document.querySelector('.mobile-nav-toggle');

    isNavCollapsed = !isNavCollapsed;

    if (isNavCollapsed) {
        navContainer.classList.add('nav-collapsed');
        navToggleIcon.classList.remove('fa-chevron-left');
        navToggleIcon.classList.add('fa-chevron-right');
    } else {
        navContainer.classList.remove('nav-collapsed');
        navToggleIcon.classList.remove('fa-chevron-right');
        navToggleIcon.classList.add('fa-chevron-left');
    }

    // For mobile view
    navContainer.classList.toggle('nav-open');
    mobileNavToggle.innerHTML = navContainer.classList.contains('nav-open') ?
        '<i class="fas fa-times"></i>' : '<i class="fas fa-bars"></i>';
}

// Initialize the schedule
document.addEventListener('DOMContentLoaded', () => {
    // Navigation toggle
    document.querySelector('.nav-toggle').addEventListener('click', toggleNav);
    document.querySelector('.mobile-nav-toggle').addEventListener('click', toggleNav);

    // Set active nav item
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => {
        item.addEventListener('click', () => {
            navItems.forEach(i => i.classList.remove('active'));
            item.classList.add('active');

            // Here you would load different content based on the section
            const section = item.getAttribute('data-section');
            console.log(`Loading ${section} section`);
        });
    });

    // Week navigation
    document.getElementById('prev-week').addEventListener('click', () => {
        if (currentWeekIndex > 0) {
            currentWeekIndex--;
            renderSchedule(currentWeekIndex);
        }
    });

    document.getElementById('next-week').addEventListener('click', () => {
        if (currentWeekIndex < scheduleData.weeks.length - 1) {
            currentWeekIndex++;
            renderSchedule(currentWeekIndex);
        }
    });

    // Render initial schedule
    renderSchedule(currentWeekIndex);
});