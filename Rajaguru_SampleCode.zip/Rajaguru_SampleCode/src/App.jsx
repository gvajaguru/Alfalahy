import { BrowserRouter, Route, Routes } from 'react-router-dom'
import './App.css'
import './components/Dashboard'
import Dashboard from './components/Dashboard'
import Header from './components/Header'
 

function App() {
  //const [count, setCount] = useState(0)

  return (
      <>
          <BrowserRouter>
              <Header />
              <Routes>
                  <Route path="/components" exact={true} element={<Dashboard /> }/>
              </Routes>
          </BrowserRouter>
          <Dashboard/>      
    </>
  )
}

export default App
