import Paper from '@mui/material/Paper';
import CssBaseline from '@mui/material/CssBaseline';
import { Container } from '@mui/material';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import LocalPhoneOutlined from '@mui/icons-material/LocalPhoneOutlined'

function createData(cname, aname, email, phone, contact) {
    return { cname, aname, email, phone, contact };
}

const rows = [
    createData('Contact Name 1', 'Account Name 1', 'email 1', 555-555-5555, 'Umanath Raju'),
    createData('Contact Name 2', 'Account Name 2', 'email 2', 555-555-5555, 'Umanath Raju'),
    createData('Contact Name 3', 'Account Name 3', 'email 3', 555-555-5555, 'Umanath Raju'),
    createData('Contact Name 4', 'Account Name 4', 'email 4', 555-555-5555, 'Umanath Raju'),
    createData('Contact Name 5', 'Account Name 5', 'email 5', 555 - 555 - 5555, 'Umanath Raju'),
    createData('Contact Name 6', 'Account Name 6', 'email 6', 555 - 555 - 5555, 'Umanath Raju'),
    createData('Contact Name 7', 'Account Name 7', 'email 7', 555 - 555 - 5555, 'Umanath Raju'),
    createData('Contact Name 8', 'Account Name 8', 'email 8', 555 - 555 - 5555, 'Umanath Raju'),
    createData('Contact Name 9', 'Account Name 9', 'email 9', 555 - 555 - 5555, 'Umanath Raju'),
    createData('Contact Name 10', 'Account Name 10', 'email 10', 555 - 555 - 5555, 'Umanath Raju')
];

function AllContacts() {
    return (
        <>
            <div className="Container Dashboard-Table">
                <div className="TableTitle">All Contacts</div>
                <TableContainer  component={Paper} sx={{ maxHeight: 340 }}>
                    <Table  stickyHeader sx={{ minWidth: 650 }} aria-label="simple table">
                        <TableHead>                            
                            <TableRow >
                                <TableCell className="RowTitle">Contact Name</TableCell>
                                <TableCell className="RowTitle" >Account Name</TableCell>
                                <TableCell className="RowTitle" >Email</TableCell>
                                <TableCell className="RowTitle" >Phone</TableCell>
                                <TableCell className="RowTitle" >Contact Owner</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody className='table-wrapper'>
                            {rows.map((row) => (
                                <TableRow
                                    key={row.cname}
                                /*sx={{ '&:last-child td, &:last-child th': { border: 0 } }}*/
                                >
                                    <TableCell component="th" scope="row"><a href="#">{row.cname}</a></TableCell>
                                    <TableCell ><a href="#">{row.aname}</a></TableCell>
                                    <TableCell ><a href="#">{row.email}</a></TableCell>
                                    <TableCell >{row.phone} <LocalPhoneOutlined className="phone-icon" /></TableCell>
                                    <TableCell >{row.contact}</TableCell>
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </TableContainer>

            </div>
            
        </>
    )
}

export default AllContacts;