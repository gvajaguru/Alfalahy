import * as React from 'react';
import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TablePagination from '@mui/material/TablePagination';
import TableRow from '@mui/material/TableRow';

const columns = [
    { id: 'title', label: 'Title' },
    { id: 'from', label: 'From' },
    { id: 'to', label: 'To' },
    { id: 'relatedto', label: 'Related To' },
    { id: 'contactname', label: 'Contact Name' },
    { id: 'host', label: 'Host' }
];

function createData(title, from, to, relatedto, contactname, host) {   
    return {title, from, to, relatedto, contactname, host};
}

const rows = [
    createData('Demo 1', '01/06/2025 10:00 AM', '01/06/2025 11:00 AM', 'Printing service', 'Name ', 'Umanath Raju'),
    createData('Demo 2', '01/06/2025 10:00 AM', '01/06/2025 11:00 AM', 'Printing service', 'Name ', 'Umanath Raju'),
    createData('Demo 3', '01/06/2025 10:00 AM', '01/06/2025 11:00 AM', 'Printing service', 'Name ', 'Umanath Raju'),
    createData('Demo 4', '01/06/2025 10:00 AM', '01/06/2025 11:00 AM', 'Printing service', 'Name ', 'Umanath Raju'),
    createData('Demo 5', '01/06/2025 10:00 AM', '01/06/2025 11:00 AM', 'Printing service', 'Name ', 'Umanath Raju'),
    createData('Demo 6', '01/06/2025 10:00 AM', '01/06/2025 11:00 AM', 'Printing service', 'Name ', 'Umanath Raju'),
    createData('Demo 7', '01/06/2025 10:00 AM', '01/06/2025 11:00 AM', 'Printing service', 'Name ', 'Umanath Raju'),
    createData('Demo 8', '01/06/2025 10:00 AM', '01/06/2025 11:00 AM', 'Printing service', 'Name ', 'Umanath Raju'),
    createData('Demo 9', '01/06/2025 10:00 AM', '01/06/2025 11:00 AM', 'Printing service', 'Name ', 'Umanath Raju'),
    createData('Demo 10', '01/06/2025 10:00 AM', '01/06/2025 11:00 AM', 'Printing service', 'Name ', 'Umanath Raju'),
    createData('Demo 11', '01/06/2025 10:00 AM', '01/06/2025 11:00 AM', 'Printing service', 'Name ', 'Umanath Raju'),
    createData('Demo 12', '01/06/2025 10:00 AM', '01/06/2025 11:00 AM', 'Printing service', 'Name ', 'Umanath Raju'),
    createData('Demo 23', '01/06/2025 10:00 AM', '01/06/2025 11:00 AM', 'Printing service', 'Name ', 'Umanath Raju'),
    createData('Demo 14', '01/06/2025 10:00 AM', '01/06/2025 11:00 AM', 'Printing service', 'Name ', 'Umanath Raju'),
    createData('Demo 15', '01/06/2025 10:00 AM', '01/06/2025 11:00 AM', 'Printing service', 'Name ', 'Umanath Raju'),
    createData('Demo 16', '01/06/2025 10:00 AM', '01/06/2025 11:00 AM', 'Printing service', 'Name ', 'Umanath Raju'),

];

export default function AllMeeting() {
    const [page, setPage] = React.useState(0);
    const [rowsPerPage, setRowsPerPage] = React.useState(10);

    const handleChangePage = (event, newPage) => {
        setPage(newPage);
    };

    const handleChangeRowsPerPage = (event) => {
        setRowsPerPage(+event.target.value);
        setPage(0);
    };

    return (
        <div className="Container Dashboard-Table">
            <div className="TableTitle">All Meetings</div>
        <Paper sx={{ width: '100%' }}>
            <TableContainer sx={{ maxHeight: 340 }}>
                <Table stickyHeader aria-label="sticky table">
                    <TableHead>                       
                        <TableRow >
                            {columns.map((column) => (
                                <TableCell className="RowTitle"
                                    key={column.id}
                                >
                                    {column.label}
                                </TableCell>
                            ))}
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {rows
                            .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                            .map((row) => {
                                return (
                                    <TableRow hover role="checkbox" tabIndex={-1} key={row.code}>
                                        { console.log("row.code "+row.code)}
                                        {columns.map((column) => {
                                            console.log(' value ' + row[column.id]);
                                            const value = row[column.id];
                                            return (
                                                <TableCell key={column.id}> 
                                                    {column.format && typeof value === 'number'
                                                        ? column.format(value)
                                                        : value}
                                                </TableCell>
                                            );
                                        })}
                                    </TableRow>
                                );
                            })}
                    </TableBody>
                </Table>
            </TableContainer>
            <TablePagination
                rowsPerPageOptions={[10, 25, 100]}
                component="div"
                count={rows.length}
                rowsPerPage={rowsPerPage}
                page={page}
                onPageChange={handleChangePage}
                onRowsPerPageChange={handleChangeRowsPerPage}
            />
            </Paper>
        </div>
    );
}
