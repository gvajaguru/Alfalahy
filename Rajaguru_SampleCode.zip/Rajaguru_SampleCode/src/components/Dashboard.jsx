import "./dashboard.css"
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import Typography from '@mui/material/Typography';
import Apartment from '@mui/icons-material/Apartment';
//import { styled } from '@mui/material/styles';
import AllContacts from './AllContacts'
import Task from './Task'
import AllMeeting from './AllMeeting'



function Dashboard() {
    return (
        <>

            <div className="tables-container">
                <div className="table-wrapper">
                        <AllContacts />
                </div>

                <div className="table-wrapper">
                        <Task />
                </div>

                <div className="table-wrapper">
                        <AllMeeting />
                </div>

               
            </div>
            
        </>
    )
}

export default Dashboard;