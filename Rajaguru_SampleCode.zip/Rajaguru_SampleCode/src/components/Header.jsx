import Apartment from '@mui/icons-material/Apartment';
function Header() {
    return (
        <>
            <div className="container-fluid top-bar">
                <div className="apartment" ><Apartment /></div> <div className="welcome">Welcome Username </div>
            </div>

        </>
    )
}

export default Header;