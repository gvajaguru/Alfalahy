import Paper from '@mui/material/Paper';
import CssBaseline from '@mui/material/CssBaseline';
import { Container } from '@mui/material';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import AccountBalanceWalletOutlinedIcon from '@mui/icons-material/AccountBalanceWalletOutlined';
import Avatar from '@mui/material/Avatar';
import Stack from '@mui/material/Stack';

function createData(subject, duedate, status, priority, relatedto, contact, task) {
    return { subject, duedate, status, priority, relatedto, contact, task };
}

const rows = [
    createData('Subject 1', '06/04/2025', 'In Progress', 'Highest', 'Related To 1', 'Umanath Raju', 'Task 1'),
    createData('Subject 2', '06/04/2025', 'In Progress', 'Highest', 'Related To 1', 'Umanath Raju', 'Task 1'),
    createData('Subject 3', '06/04/2025', 'In Progress', 'Highest', 'Related To 1', 'Umanath Raju', 'Task 1'),
    createData('Subject 4', '06/04/2025', 'In Progress', 'Highest', 'Related To 1', 'Umanath Raju', 'Task 1'),
    createData('Subject 5', '06/04/2025', 'In Progress', 'Highest', 'Related To 1', 'Umanath Raju', 'Task 1'),
    createData('Subject 6', '06/04/2025', 'In Progress', 'Highest', 'Related To 1', 'Umanath Raju', 'Task 1'),
    createData('Subject 7', '06/04/2025', 'In Progress', 'Highest', 'Related To 1', 'Umanath Raju', 'Task 1'),
  
];

function Task() {
    return (
        <>
            <div className="Container Dashboard-Table">
                <div className="TableTitle">All Task</div>
                <div sx={{ width: 1000 }}>
                <TableContainer component={Paper} sx={{ maxHeight: 340}}>
                    <Table stickyHeader sx={{ minWidth: 650, width:800 }} aria-label="simple table">
                    <TableHead>                       
                        <TableRow >
                            <TableCell className="RowTitle">Subject</TableCell>
                            <TableCell className="RowTitle" >Due Date</TableCell>
                                <TableCell className="RowTitle" >Status</TableCell>
                                <TableCell className="RowTitle" >Priority</TableCell>
                                <TableCell className="RowTitle" >Related To</TableCell>
                                <TableCell className="RowTitle" >Contact Name</TableCell>
                                <TableCell className="RowTitle" >Task</TableCell>
                    </TableRow>
                </TableHead>
                        <TableBody className="overflowx">
                        {rows.map((row) => (
                            <TableRow
                                key={row.subject}
                            /*sx={{ '&:last-child td, &:last-child th': { border: 0 } }}*/
                            >
                                <TableCell ><a href="#">{row.subject}</a></TableCell>
                            <TableCell component="th" scope="row">
                                {row.duedate}
                            </TableCell>
                            <TableCell >{row.status}</TableCell>
                            <TableCell >{row.priority}</TableCell>
                                <TableCell ><AccountBalanceWalletOutlinedIcon /><a href="#"> {row.relatedto}</a></TableCell>
                                <TableCell><div className='contactName-icon'><Avatar  alt="Remy Sharp" src="./src/assets/1.jpg" /></div><a href="#">{row.contact}</a></TableCell>
                            <TableCell >{row.task}</TableCell>
                        </TableRow>
                    ))} 
                </TableBody>
            </Table>
                </TableContainer>
                </div></div>
        </>
    )
}

export default Task;