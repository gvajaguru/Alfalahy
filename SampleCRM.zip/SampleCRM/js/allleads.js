﻿$(document).ready(function () {
    // Sample data for the table
    const leadsData = {
        all: [
            { radiobutton: '', company: "Acme Corp", email: "john@acme.com", leadname: "John", lastname: " Smith", leadowner: "Umanath", title: "Manager", phone: "(555) 123-4567", mobile: "(555) 123-4567", fax: "" },
            { radiobutton: '', company: "Globex", email: "sarah@globex.com", leadname: "Sarah", lastname: "Johnson", leadowner: "Umanath", title: "Team Lead", phone: "(555) 234-5678", mobile: "(555) 234-5678", fax: "" },
            {
                radiobutton: '', company: "Initech", email: "michael@initech.com", leadname: "Michael", lastname: "Brown", leadowner: "Umanath", title: "Office Assistance", phone: "(555) 345-6789", mobile: "(555) 345-6789", fax: ""
            },
            { radiobutton: '', company: "Umbrella Corp", email: "emily@umbrella.com", leadname: "Emily", lastname: "Davis", leadowner: "Umanath", title: "Executive secretary", phone: "(555) 456-7890", mobile: "(555) 456-7890", fax: "" },
            { radiobutton: '', company: "Wayne Ent", email: "david@wayne.com", leadname: "David", lastname: "Wilson", leadowner: "Umanath", title: "Mechanical system Enginner", phone: "(555) 567-8901", mobile: "(555) 567-8901", fax: "", },
            {
                radiobutton: '', company: "Stark Ind", email: "jennifer@stark.com", leadname: "Jennifer", lastname: "Lee", leadowner: "Umanath", title: "Cost Accountant", phone: "(555) 678-9012", mobile: "(555) 678-9012", fax: ""
            },
            { radiobutton: '', company: "Oscorp", email: "robert@oscorp.com", leadname: "Robert", lastname: "Taylor", leadowner: "Umanath", title: "Director of Sales", phone: "(555) 789-0123", mobile: "(555) 789-0123", fax: "" },
            { radiobutton: '', company: "Cyberdyne", email: "lisa@cyberdyne.com", leadname: "Lisa", lastname: "Martinez", leadowner: "Umanath", title: "VP Accounting", phone: "(555) 890-1234", mobile: "(555) 890-1234", fax: "" }
        ],
        converted: [
            { radiobutton: '', company: "Acme Corp", email: "john@acme.com", leadname: "John", lastname: "Smith", leadowner: "Umanath", title: "Manager", phone: "(555) 123-4567", mobile: "(555) 123-4567", fax: "" },
            { radiobutton: '', company: "Oscorp", email: "robert@oscorp.com", leadname: "Robert", lastname: "Taylor", leadowner: "Umanath", title: "Director of Sales", phone: "(555) 789-0123", mobile: "(555) 789-0123", fax: "" }
        ],
        junk: [
            {
                radiobutton: '', company: "Globex", email: "sarah@globex.com", leadname: "Sarah", lastname: "Johnson", leadowner: "Umanath", title: "Team Lead", phone: "(555) 234-5678", mobile: "(555) 234-5678", fax: ""
            },
            { radiobutton: '', company: "Cyberdyne", email: "lisa@cyberdyne.com", leadname: "Lisa", lastname: "Martinez", leadowner: "Umanath", title: "VP Accounting", phone: "(555) 890-1234", mobile: "(555) 890-1234", fax: "" }
        ],
        mailing: [
            { radiobutton: '', company: "Initech", email: "michael@initech.com", leadname: "Michael", lastname: "Brown", leadowner: "Umanath", title: "Office Assistance", phone: "(555) 345-6789", mobile: "(555) 345-6789", fax: "" }
        ],
        openleads: [
            { radiobutton: '', company: "Umbrella Corp", email: "emily@umbrella.com", leadname: "Emily", lastname: "Davis", leadowner: "Umanath", title: "Executive secretary", phone: "(555) 456-7890", mobile: "(555) 456-7890", fax: "" }
        ],
        unread: [],
        recent: [
            { radiobutton: '', company: "Wayne Ent", email: "david@wayne.com", leadname: "David", lastname: "Wilson", leadowner: "Umanath", title: "Mechanical system Enginner", phone: "(555) 567-8901", mobile: "(555) 567-8901", fax: "" }
        ],
        today: [
            { radiobutton: '', company: "Stark Ind", email: "jennifer@stark.com", leadname: "Jennifer", lastname: "Lee", leadowner: "Umanath", title: "Cost Accountant", phone: "(555) 678-9012", mobile: "(555) 678-9012", fax: "" }
        ]
    };

    // Initialize table with all leads
    renderTable('all');

    // Toggle dropdown menu
    $('#mainDropdown .dropdown-toggle').click(function (e) {
        e.stopPropagation();
        $('#mainDropdown').toggleClass('active');
        $('.dropdown').not($('#mainDropdown')).removeClass('active');
    });

    // Close dropdown when clicking outside
    $(document).click(function (e) {
        if (!$(e.target).closest('.dropdown').length) {
            $('.dropdown').removeClass('active');
        }
    });

    $(document).click(function (e) {
        if (!$(e.target).closest('.sort-dropdown').length) {
            $('.sort-dropdown').removeClass('active');
        }
    });


    // Filter dropdown list
    $('#dropdownSearch').on('input', function () {
        const searchTerm = $(this).val().toLowerCase();
        $('#dropdownList li').each(function () {
            const text = $(this).text().toLowerCase();
            $(this).toggle(text.includes(searchTerm));
        });
    });

    // Select dropdown item
    $('#dropdownList li').click(function () {
        const value = $(this).data('value');
        const text = $(this).text();
        $('#selectedOption').text(text);
        $('#mainDropdown').removeClass('active');

        // Update table based on selection
        renderTable(value);
    });

    // Toggle left menu
    $('#toggleMenu').click(function () {
        $('#leftMenu').toggleClass('collapsed');       
        const menuToggle = document.getElementById('leftMenu');
        const menuItems = document.getElementById('menu-scrollable');
        if (menuToggle.classList.contains('collapsed')) {
            $(".menu-scrollable").css('visibility', 'hidden');
        } else {
            $(".menu-scrollable").css('visibility', 'visible');
        }
    });

    // Filter left menu items
    $('#menuSearch').on('input', function () {
        const searchTerm = $(this).val().toLowerCase();
        $('.menu-item').each(function () {
            const text = $(this).find('label').text().toLowerCase();
            $(this).toggle(text.includes(searchTerm));
        });
    });

    // Toggle sort dropdown
    $('.sort-btn').click(function (e) {
        e.stopPropagation();
        const dropdown = $(this).next('.sort-dropdown');
        $('.sort-dropdown').not(dropdown).removeClass('active');
        dropdown.toggleClass('active');
    });

    // Sort table actions
    $('.sort-dropdown li').click(function () {
        const action = $(this).data('action');
        const col = $(this).closest('.sort-dropdown').prev().data('col');
        const th = $(this).closest('th');

        switch (action) {
            case 'asc':
                sortTable(col, 'asc');
                break;
            case 'desc':
                sortTable(col, 'desc');
                break;
            case 'filter':
                alert(`Filter by ${col} column`);
                break;
            case 'unsort':
                // Reset to original order
                const currentFilter = $('#selectedOption').text().toLowerCase().replace(' ', '');
                renderTable(currentFilter);
                break;
            case 'hide':
                th.hide();
                $(`td:nth-child(${th.index() + 1})`).hide();
                break;
        }

        $(this).closest('.sort-dropdown').removeClass('active');
    });

    // Function to render table based on selected filter
    function renderTable(filter) {
        const data = leadsData[filter] || leadsData.all;
        const $tableBody = $('#tableBody');
        $tableBody.empty();

        data.forEach(lead => {
            $tableBody.append(`
                                <tr class="leads-table">
                                    <td class="sticky-col"><input type="checkbox" id='${lead.company}' class="rowCheckbox"><label for="${lead.company}">${lead.radiobutton}</label>
                                    <td class="sticky-col nav-ok">${lead.company}</td>
                                    <td class="hover-color-change nav-ok">${lead.email}</td>
                                    <td class="hover-color-change nav-ok">${lead.leadname}</td>
                                    <td class="hover-color-change nav-ok">${lead.lastname}</td>
                                    <td class="nav-ok">${lead.leadowner}</td>
                                    <td class="nav-ok">${lead.title}</td>
                                    <td class="nav-ok">${lead.phone}</td>
                                    <td class="nav-ok">${lead.mobile}</td>
                                    <td class="nav-ok">${lead.fax}</td>
                                </tr>
                            `);
        });
    }

    // Function to sort table
    function sortTable(col, direction) {
        const $rows = $('#tableBody tr').get();

        $rows.sort((a, b) => {
            const aVal = $(a).find(`td:eq(${getColumnIndex(col)})`).text().toLowerCase();
            const bVal = $(b).find(`td:eq(${getColumnIndex(col)})`).text().toLowerCase();

            if (direction === 'asc') {
                return aVal.localeCompare(bVal);
            } else {
                return bVal.localeCompare(aVal);
            }
        });

        $('#tableBody').empty().append($rows);
    }

    // Helper function to get column index
    function getColumnIndex(col) {
        const headers = ['r','company', 'email', 'leadname', 'lastname', 'leadowner', 'title', 'phone', 'mobile', 'fax'];
        return headers.indexOf(col);
    }

    // Helper function to get status color
    function getStatusColor(status) {
        const colors = {
            'New': '#4e73df',
            'Contacted': '#1cc88a',
            'Qualified': '#36b9cc',
            'Proposal Sent': '#f6c23e',
            'Closed Won': '#4e73df',
            'Closed Lost': '#e74a3b'
        };
        return colors[status] || '#858796';
    }

    // Select all check box
    const selectAll = document.getElementById('selectAll');
    const rowCheckboxes = document.querySelectorAll('.rowCheckbox');

    // Select All functionality
    selectAll.addEventListener('change', function () {
        rowCheckboxes.forEach(checkbox => {
            checkbox.checked = selectAll.checked;
        });
    });

    // Update Select All when individual checkboxes change
    rowCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', function () {
            const allChecked = [...rowCheckboxes].every(cb => cb.checked);
            selectAll.checked = allChecked;
            selectAll.indeterminate = !allChecked && [...rowCheckboxes].some(cb => cb.checked);
        });
    });

    $('.nav-ok').click(function (e) {
        e.stopPropagation(); 
        window.location.replace("userdetails.html");
    });
});