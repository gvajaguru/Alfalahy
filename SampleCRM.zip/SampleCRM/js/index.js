﻿$(document).ready(function () {
    $('.three-dots').click(function () {
        alert("3 dots clicked");
        console.log("Checking");
    });
});