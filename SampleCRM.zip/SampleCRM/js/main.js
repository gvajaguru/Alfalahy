﻿$(document).ready(function () {
    // Sample data for the table
    const tableData = {
        dashboard: [
            { name: "Dashboard Item 1", email: "dash1@example.com", phone: "123-456-7890", status: "Active", date: "2023-05-01" },
            { name: "Dashboard Item 2", email: "dash2@example.com", phone: "234-567-8901", status: "Inactive", date: "2023-05-02" },
            { name: "Dashboard Item 3", email: "dash3@example.com", phone: "345-678-9012", status: "Pending", date: "2023-05-03" }
        ],
        leads: [
            { name: "John Doe", email: "john@example.com", phone: "555-123-4567", status: "New", date: "2023-05-10" },
            { name: "Jane Smith", email: "jane@example.com", phone: "555-234-5678", status: "Contacted", date: "2023-05-11" },
            { name: "Robert Johnson", email: "robert@example.com", phone: "555-345-6789", status: "Qualified", date: "2023-05-12" },
            { name: "Emily Davis", email: "emily@example.com", phone: "555-456-7890", status: "New", date: "2023-05-13" }
        ],
        customers: [
            { name: "Acme Corp", email: "contact@acme.com", phone: "555-111-2222", status: "Active", date: "2023-04-15" },
            { name: "Globex Inc", email: "info@globex.com", phone: "555-222-3333", status: "Active", date: "2023-04-20" },
            { name: "Initech", email: "support@initech.com", phone: "555-333-4444", status: "Inactive", date: "2023-04-25" }
        ],
        orders: [
            { name: "Order #1001", email: "john@example.com", phone: "555-123-4567", status: "Shipped", date: "2023-05-01" },
            { name: "Order #1002", email: "jane@example.com", phone: "555-234-5678", status: "Processing", date: "2023-05-05" },
            { name: "Order #1003", email: "robert@example.com", phone: "555-345-6789", status: "Delivered", date: "2023-05-10" }
        ]
    };

    // Initialize the table with dashboard data
    updateTable('dashboard');
    $('#contentTitle').text('Dashboard');

    // Toggle left menu
    $('#toggleMenu').click(function () {
        $('.left-menu').toggleClass('collapsed');
    });

    // Left menu item click handler
    $('.menu-item').click(function () {
        $('.menu-item').removeClass('active');
        $(this).addClass('active');
        const content = $(this).data('content');
        $('#contentTitle').text($(this).find('span').text());
        updateTable(content);
    });

    // Menu search functionality
    $('#menuSearch').on('input', function () {
        const searchTerm = $(this).val().toLowerCase();
        $('.menu-item').each(function () {
            const text = $(this).find('span').text().toLowerCase();
            if (text.includes(searchTerm)) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    });

    // Dropdown search functionality
    $('#mainDropdown').on('focus', function () {
        $('.dropdown-search-container').addClass('show');
        populateDropdownOptions();
    });

    $(document).on('click', function (e) {
        if (!$(e.target).closest('.dropdown-container').length) {
            $('.dropdown-search-container').removeClass('show');
        }
    });

    $('#dropdownSearch').on('input', function () {
        const searchTerm = $(this).val().toLowerCase();
        $('.dropdown-option').each(function () {
            const text = $(this).text().toLowerCase();
            if (text.includes(searchTerm)) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    });

    function populateDropdownOptions() {
        const $dropdown = $('.dropdown-options');
        $dropdown.empty();

        $('#mainDropdown option').each(function () {
            if ($(this).val()) {
                $dropdown.append(`<div class="dropdown-option" data-value="${$(this).val()}">${$(this).text()}</div>`);
            }
        });

        $('.dropdown-option').click(function () {
            const value = $(this).data('value');
            $('#mainDropdown').val(value);
            $('.dropdown-search-container').removeClass('show');
            updateTable(value);
            $('#contentTitle').text($(this).text());
        });
    }

    // Table sorting functionality
    let currentSort = { column: null, direction: 'asc' };

    $('.btn-sort').click(function () {
        const column = $(this).data('sort');

        if (currentSort.column === column) {
            currentSort.direction = currentSort.direction === 'asc' ? 'desc' : 'asc';
        } else {
            currentSort.column = column;
            currentSort.direction = 'asc';
        }

        $(this).text(`Sort by Name ${currentSort.direction === 'asc' ? '↑' : '↓'}`);
        sortTable(currentSort.column, currentSort.direction);
    });

    // Unsort button
    $('.btn-unsort').click(function () {
        currentSort = { column: null, direction: 'asc' };
        $('.btn-sort').text('Sort by Name');
        const currentContent = $('.menu-item.active').data('content');
        updateTable(currentContent);
    });

    // Column visibility toggle
    $('.column-option input').change(function () {
        const columnId = $(this).attr('id').replace('col-', '');
        const columnIndex = $('th').index($(`th:contains(${columnId.charAt(0).toUpperCase() + columnId.slice(1)})`));

        if ($(this).is(':checked')) {
            $(`th:nth-child(${columnIndex + 1}), td:nth-child(${columnIndex + 1})`).show();
        } else {
            $(`th:nth-child(${columnIndex + 1}), td:nth-child(${columnIndex + 1})`).hide();
        }
    });

    // Update table with data
    function updateTable(content) {
        const data = tableData[content] || [];
        const $tbody = $('#dataTable tbody');
        $tbody.empty();

        data.forEach(item => {
            $tbody.append(`
                <tr>
                    <td class="sticky-col">${item.name}</td>
                    <td>${item.email}</td>
                    <td>${item.phone}</td>
                    <td><span class="status-badge ${item.status.toLowerCase()}">${item.status}</span></td>
                    <td>${item.date}</td>
                    <td><button class="btn-action">View</button></td>
                </tr>
            `);
        });
    }

    // Sort table
    function sortTable(column, direction) {
        const $table = $('#dataTable');
        const $rows = $table.find('tr:gt(0)').toArray();

        $rows.sort((a, b) => {
            const aVal = $(a).find('td').eq(getColumnIndex(column)).text().toLowerCase();
            const bVal = $(b).find('td').eq(getColumnIndex(column)).text().toLowerCase();

            if (direction === 'asc') {
                return aVal.localeCompare(bVal);
            } else {
                return bVal.localeCompare(aVal);
            }
        });

        $.each($rows, (index, row) => {
            $table.append(row);
        });
    }

    function getColumnIndex(columnName) {
        const headers = $('#dataTable th').map((i, th) => $(th).text().toLowerCase()).get();
        return headers.indexOf(columnName.toLowerCase());
    }

    // Add some style to status badges
    $('head').append(`
        <style>
            .status-badge {
                padding: 4px 8px;
                border-radius: 12px;
                font-size: 12px;
                font-weight: 500;
            }
            .status-badge.active, .status-badge.shipped, .status-badge.qualified {
                background-color: #e6f7e6;
                color: #2e7d32;
            }
            .status-badge.inactive {
                background-color: #ffebee;
                color: #c62828;
            }
            .status-badge.pending, .status-badge.new, .status-badge.processing {
                background-color: #fff8e1;
                color: #f57f17;
            }
            .status-badge.contacted {
                background-color: #e3f2fd;
                color: #1565c0;
            }
        </style>
    `);
});