﻿$(document).ready(function () {
    // Toggle left menu
    $('#toggleMenu').click(function () {
        $('#leftMenu').toggleClass('collapsed');
    });

    // Toggle details section
    $('#detailsToggle').click(function () {
        $(this).toggleClass('collapsed');
        $('#detailsContent').slideToggle();

        if ($(this).hasClass('collapsed')) {
            $(this).find('span').text('Show Details');
        } else {
            $(this).find('span').text('Hide Details');
        }
    });

    // View toggle switch
    $('.toggle-option').click(function () {
        if (!$(this).hasClass('active')) {
            $('.toggle-option').removeClass('active');
            $(this).addClass('active');

            if ($(this).text() === 'Timeline') {
                $('.toggle-bg').addClass('timeline');
            } else {
                $('.toggle-bg').removeClass('timeline');
            }
        }
    });

    // Editable fields functionality
    $('.editable-value').each(function () {
        const $value = $(this).find('span');
        const originalValue = $value.text();
        const $editable = $(this);

        // Cancel button
        $(this).find('.edit-btn.cancel').click(function (e) {
            e.stopPropagation();
            $value.text(originalValue);
            $editable.removeClass('editing');
        });

        // Save button
        $(this).find('.edit-btn.save').click(function (e) {
            e.stopPropagation();
            // Here you would typically save to database
            alert('Value saved: ' + $value.text());
            $editable.removeClass('editing');
        });

        // Make the value editable on click
        $value.on('click', function (e) {
            e.stopPropagation();
            const currentValue = $(this).text();
            $(this).html(`<input type="text" class="editable-input" value="${currentValue}">`);
            $editable.addClass('editing');

            const $input = $(this).find('input');
            $input.focus();

            $input.on('blur', function () {
                $value.text($(this).val());
                $editable.removeClass('editing');
            });

            $input.on('keydown', function (e) {
                if (e.key === 'Enter') {
                    $value.text($(this).val());
                    $editable.removeClass('editing');
                } else if (e.key === 'Escape') {
                    $value.text(originalValue);
                    $editable.removeClass('editing');
                }
            });
        });
    });
    $('#backArrow').click(function () {
        window.location.replace("allleads.html");
    });
});