﻿$(document).ready(function () {
    // Mobile menu toggle
    $('.mobile-menu-btn').click(function (e) {
        e.stopPropagation();
        $('.mobile-menu').toggleClass('active');
    });

    // Close mobile menu when clicking anywhere
    $(document).click(function () {
        $('.mobile-menu').removeClass('active');
    });

    // Prevent menu from closing when clicking inside it
    $('.mobile-menu').click(function (e) {
        e.stopPropagation();
    });

    // View selector dropdown
    $('.view-selector-btn').click(function () {
        $('.view-dropdown').toggleClass('active');
    });

    // Close dropdown when clicking outside
    $(document).click(function (e) {
        if (!$(e.target).closest('.view-selector').length) {
            $('.view-dropdown').removeClass('active');
        }
    });

    // Filter view items
    $('.view-dropdown input').on('input', function () {
        const searchTerm = $(this).val().toLowerCase();
        $('.dropdown-item').each(function () {
            const text = $(this).text().toLowerCase();
            if (text.includes(searchTerm)) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    });

    // Clear search
    $('.clear-search').click(function () {
        $('.view-dropdown input').val('');
        $('.dropdown-item').show();
    });

    // Select view
    $('.dropdown-item').click(function () {
        const view = $(this).data('view');
        $('.view-selector-btn span').text($(this).text());
        $('.view-dropdown').removeClass('active');
        loadLeads(view);
    });

    // Sidebar toggle
    $('.sidebar-toggle').click(function () {
        $('.sidebar').toggleClass('collapsed');
        const menuItems = document.getElementById('side-bar');
        if (menuItems.classList.contains('collapsed')) {
            $(".sidebar-content").css('display', 'none');
        } else {
            $(".sidebar-content").css('display', 'block');
        }
    });

    // Filter sidebar items
    $('.sidebar-search input').on('input', function () {
        const searchTerm = $(this).val().toLowerCase();
        $('.filter-item').each(function () {
            const text = $(this).text().toLowerCase();
            if (text.includes(searchTerm)) {
                $(this).show();
            } else {
                $(this).hide();
            }
        });
    });

    // Clear filter search
    $('.clear-filter').click(function () {
        $('.sidebar-search input').val('');
        $('.filter-item').show();
    });

    // Collapse filter sections
    $('.filter-section-title').click(function () {
        $(this).parent().find('.filter-items').slideToggle();
        $(this).find('i').toggleClass('fa-chevron-down fa-chevron-up');
    });

    // Table sort options
    $('.sort-btn').click(function (e) {
        e.stopPropagation();
        $(this).siblings('.sort-options').toggleClass('active');
    });

    // Close sort options when clicking outside
    $(document).click(function () {
        $('.sort-options').removeClass('active');
    });

    // Table sorting functionality
    let currentSortColumn = null;
    let currentSortDirection = 'asc';

    // Sort option selection handler
    $('.sort-option').click(function () {
        const action = $(this).data('sort');
        const $header = $(this).closest('th');
        const columnIndex = $header.index();
        const columnName = $header.text().trim().replace(/\s+/g, '-').toLowerCase();

        // Close all sort options
        $('.sort-options').removeClass('active');

        switch (action) {
            case 'asc':
                sortTable(columnIndex, 'asc');
                updateSortIndicator($header, 'asc');
                break;
            case 'desc':
                sortTable(columnIndex, 'desc');
                updateSortIndicator($header, 'desc');
                break;
            case 'filter':
                showFilterDialog(columnName);
                break;
            case 'unsort':
                resetSort();
                break;
            case 'hide':
                $header.hide();
                $('tbody tr').each(function () {
                    $(this).find('td').eq(columnIndex).hide();
                });
                break;
        }
    });

    // Function to sort the table
    function sortTable(columnIndex, direction) {
        const $table = $('table');
        const $tbody = $table.find('tbody');
        const $rows = $tbody.find('tr').get();

        $rows.sort(function (a, b) {
            const aVal = $(a).find('td').eq(columnIndex).text().trim().toLowerCase();
            const bVal = $(b).find('td').eq(columnIndex).text().trim().toLowerCase();

            // Check if values are numeric
            const aNum = parseFloat(aVal.replace(/[^0-9.-]/g, ''));
            const bNum = parseFloat(bVal.replace(/[^0-9.-]/g, ''));

            if (!isNaN(aNum) && !isNaN(bNum)) {
                return direction === 'asc' ? aNum - bNum : bNum - aNum;
            } else {
                // String comparison
                if (aVal < bVal) return direction === 'asc' ? -1 : 1;
                if (aVal > bVal) return direction === 'asc' ? 1 : -1;
                return 0;
            }
        });

        $.each($rows, function (index, row) {
            $tbody.append(row);
        });

        currentSortColumn = columnIndex;
        currentSortDirection = direction;
    }

    // Function to reset sorting
    function resetSort() {
        // Reload the original data
        const currentView = $('.view-selector-btn span').text().toLowerCase().replace(' ', '-');
        loadLeads(currentView);

        // Remove sort indicators
        $('th').find('.sort-indicator').remove();
        currentSortColumn = null;
        currentSortDirection = 'asc';
    }

   
    // Select all checkbox
    $('#select-all').change(function () {
        $('tbody input[type="checkbox"]').prop('checked', $(this).prop('checked'));
    });

    // Sample data for leads
    const leadsData = {
        all: [
            { company: 'Acme Inc', email: 'john@acme.com', firstName: 'John', lastName: 'Doe', owner: 'Sarah Smith', title: 'CEO', phone: '555-1234', mobile: '555-5678', fax: '555-9012', status: 'new', source: 'web' },
            { company: 'Globex Corp', email: 'jane@globex.com', firstName: 'Jane', lastName: 'Smith', owner: 'Mike Johnson', title: 'CTO', phone: '555-2345', mobile: '555-6789', fax: '555-0123', status: 'contacted', source: 'phone' },
            { company: 'Initech', email: 'peter@initech.com', firstName: 'Peter', lastName: 'Gibbons', owner: 'Bill Lumbergh', title: 'Developer', phone: '555-3456', mobile: '555-7890', fax: '555-1234', status: 'qualified', source: 'referral' },
            { company: 'Umbrella Corp', email: 'alice@umbrella.com', firstName: 'Alice', lastName: 'Jones', owner: 'Albert Wesker', title: 'Researcher', phone: '555-4567', mobile: '555-8901', fax: '555-2345', status: 'lost', source: 'email' },
            { company: 'Stark Industries', email: 'tony@stark.com', firstName: 'Tony', lastName: 'Stark', owner: 'Pepper Potts', title: 'Owner', phone: '555-5678', mobile: '555-9012', fax: '555-3456', status: 'new', source: 'web' },
            { company: 'Wayne Enterprises', email: 'bruce@wayne.com', firstName: 'Bruce', lastName: 'Wayne', owner: 'Lucius Fox', title: 'CEO', phone: '555-6789', mobile: '555-0123', fax: '555-4567', status: 'contacted', source: 'phone' },
            { company: 'Oscorp', email: 'harry@oscorp.com', firstName: 'Harry', lastName: 'Osborn', owner: 'Norman Osborn', title: 'VP', phone: '555-7890', mobile: '555-1234', fax: '555-5678', status: 'qualified', source: 'referral' },
            { company: 'Pied Piper', email: 'richard@piedpiper.com', firstName: 'Richard', lastName: 'Hendricks', owner: 'Erlich Bachman', title: 'Founder', phone: '555-8901', mobile: '555-2345', fax: '555-6789', status: 'new', source: 'email' }
        ],
        new: [
            { company: 'Acme Inc', email: 'john@acme.com', firstName: 'John', lastName: 'Doe', owner: 'Sarah Smith', title: 'CEO', phone: '555-1234', mobile: '555-5678', fax: '555-9012', status: 'new', source: 'web' },
            { company: 'Stark Industries', email: 'tony@stark.com', firstName: 'Tony', lastName: 'Stark', owner: 'Pepper Potts', title: 'Owner', phone: '555-5678', mobile: '555-9012', fax: '555-3456', status: 'new', source: 'web' },
            { company: 'Pied Piper', email: 'richard@piedpiper.com', firstName: 'Richard', lastName: 'Hendricks', owner: 'Erlich Bachman', title: 'Founder', phone: '555-8901', mobile: '555-2345', fax: '555-6789', status: 'new', source: 'email' }
        ],
        contacted: [
            { company: 'Globex Corp', email: 'jane@globex.com', firstName: 'Jane', lastName: 'Smith', owner: 'Mike Johnson', title: 'CTO', phone: '555-2345', mobile: '555-6789', fax: '555-0123', status: 'contacted', source: 'phone' },
            { company: 'Wayne Enterprises', email: 'bruce@wayne.com', firstName: 'Bruce', lastName: 'Wayne', owner: 'Lucius Fox', title: 'CEO', phone: '555-6789', mobile: '555-0123', fax: '555-4567', status: 'contacted', source: 'phone' }
        ],
        qualified: [
            { company: 'Initech', email: 'peter@initech.com', firstName: 'Peter', lastName: 'Gibbons', owner: 'Bill Lumbergh', title: 'Developer', phone: '555-3456', mobile: '555-7890', fax: '555-1234', status: 'qualified', source: 'referral' },
            { company: 'Oscorp', email: 'harry@oscorp.com', firstName: 'Harry', lastName: 'Osborn', owner: 'Norman Osborn', title: 'VP', phone: '555-7890', mobile: '555-1234', fax: '555-5678', status: 'qualified', source: 'referral' }
        ],
        lost: [
            { company: 'Umbrella Corp', email: 'alice@umbrella.com', firstName: 'Alice', lastName: 'Jones', owner: 'Albert Wesker', title: 'Researcher', phone: '555-4567', mobile: '555-8901', fax: '555-2345', status: 'lost', source: 'email' }
        ],
        recent: [
            { company: 'Pied Piper', email: 'richard@piedpiper.com', firstName: 'Richard', lastName: 'Hendricks', owner: 'Erlich Bachman', title: 'Founder', phone: '555-8901', mobile: '555-2345', fax: '555-6789', status: 'new', source: 'email' },
            { company: 'Wayne Enterprises', email: 'bruce@wayne.com', firstName: 'Bruce', lastName: 'Wayne', owner: 'Lucius Fox', title: 'CEO', phone: '555-6789', mobile: '555-0123', fax: '555-4567', status: 'contacted', source: 'phone' }
        ],
        hot: [
            { company: 'Stark Industries', email: 'tony@stark.com', firstName: 'Tony', lastName: 'Stark', owner: 'Pepper Potts', title: 'Owner', phone: '555-5678', mobile: '555-9012', fax: '555-3456', status: 'new', source: 'web' },
            { company: 'Initech', email: 'peter@initech.com', firstName: 'Peter', lastName: 'Gibbons', owner: 'Bill Lumbergh', title: 'Developer', phone: '555-3456', mobile: '555-7890', fax: '555-1234', status: 'qualified', source: 'referral' }
        ],
        cold: [
            { company: 'Umbrella Corp', email: 'alice@umbrella.com', firstName: 'Alice', lastName: 'Jones', owner: 'Albert Wesker', title: 'Researcher', phone: '555-4567', mobile: '555-8901', fax: '555-2345', status: 'lost', source: 'email' }
        ]
    };

    // Function to load leads into table
    function loadLeads(view) {
        const leads = leadsData[view] || leadsData.all;
        const $tbody = $('#leads-table-body');
        $tbody.empty();

        leads.forEach(lead => {
            $tbody.append(`
                        <tr>
                            <td class="sticky-col">
                                <input type="checkbox" id="lead-${lead.email}">
                                <label for="lead-${lead.email}">${lead.company}</label>
                            </td>
                            <td>${lead.email}</td>
                            <td>${lead.firstName}</td>
                            <td>${lead.lastName}</td>
                            <td>${lead.owner}</td>
                            <td>${lead.title}</td>
                            <td>${lead.phone}</td>
                            <td>${lead.mobile}</td>
                            <td>${lead.fax}</td>
                        </tr>
                    `);
        });
    }

    // Initial load
    loadLeads('all');
});